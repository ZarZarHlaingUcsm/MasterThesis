import org.eclipse.swt.SWT;
import java.lang.String;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import java.lang.NullPointerException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.io.*;
import java.lang.ArrayIndexOutOfBoundsException;
import org.eclipse.swt.custom.ScrolledComposite;
import org.omg.CORBA.StringValueHelper;

public class HomonymDisambiguationSystem extends Shell {	
	public static String tagForWegSeg="";
	public static  String tagForCorSeg="";
	static String segSeq = "";
	static String resultText = "",resultText2="";
	static String letterSeq = "";
	static String input="";
	//static String input ="လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	//= "လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	static String letterSeq1 = "", letterSeq2 = "", letterSeq3 = "";
	static String input1 = "", input2 = "", input3 = "";
	public String anotherHomonymWord = "";
	private static Text txtInputString;
	public String tempTokenizedText;
	private Text txtTokenizedText;
	private Text txtHomonymWords;
	static String segSequence = "";
	static String resultSequence = "";
	static String letterSequence = "";
	static String inputSequence = "";
	public String finalResultForCorSen = "";
	//static String letterSeq1, letterSeq2, letterSeq3;
	static String inputSeq1 = "";
	public int countForCorSequence = 0;
	public int countForWrgSequence = 0;
	public String finalResultForWrgSen = "";
	private static int[] convertArr = null;
	private Text txtSegWords;
	public String tempstr = "";
	public String symbolForCorTag = "";
	//--------------------------------- variables for correct homonym sentence--------------------------------------------
	public String[] tokensForCorrectHomo = null;
	public String stringForCorrectHomo = "";
	private Text txtSegCorWord;
	private Text txtNextTokenizeSen;
	private Text txtFinalResult;
	public String symbolForLexicon = "";
	//-------------------------------------------------------------------------------------------------------------------------------

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String args[]) throws FileNotFoundException {
		try {
			Display display = Display.getDefault();
			HomonymDisambiguationSystem shell = new HomonymDisambiguationSystem(display);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell.
	 * 
	 * @param display
	 */
	public HomonymDisambiguationSystem(Display display) {
		super(display, SWT.SHELL_TRIM);
		txtInputString = new Text(this, SWT.BORDER);
		txtInputString.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		txtInputString.setBounds(180, 40, 367, 35);
		Label lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		lblNewLabel.setBounds(52, 96, 114, 29);
		lblNewLabel.setText("Tokenized Text");
		Label lblNewLabel_1 = new Label(this, SWT.NONE);
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		lblNewLabel_1.setBounds(73, 40, 93, 35);
		lblNewLabel_1.setText("Input String");
		txtTokenizedText = new Text(this, SWT.BORDER);
		txtTokenizedText.setFont(SWTResourceManager.getFont("Myanmar3", 12,	SWT.NORMAL));
		txtTokenizedText.setBounds(180, 81, 367, 35);
		Button btnTokenize = new Button(this, SWT.NONE);
		btnTokenize.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {		
				String tokenizedText=WordTokenAndSegment.tokenText(txtInputString.getText().toString());
				txtTokenizedText.setText(tokenizedText);
				tempTokenizedText = tokenizedText;
				}
		});
		btnTokenize.setFont(SWTResourceManager.getFont("Myanmar3", 12,
				SWT.NORMAL));
		btnTokenize.setBounds(565, 45, 144, 53);
		btnTokenize.setText("Tokenize");
		Button btnCheckHomonym = new Button(this, SWT.NONE);
		btnCheckHomonym.addSelectionListener(new SelectionAdapter() {
			@Override
				public void widgetSelected(SelectionEvent arg0) {
				stringForCorrectHomo="";
				//----------------------------------To read homonyms from Notepad------------------------------------------
				String filePath = "D:\\NLPworkspace\\NLPToken\\HomonymWords.txt";
				BufferedReader br;
				String line = "";
				anotherHomonymWord = " ";
				// double probability=0.0;
				//------------------------------------ For To check word is homonym or not-----------------------------------
				String tokenizedMynText = txtTokenizedText.getText();
				System.out.println("Tokenized text==="+tokenizedMynText);
				String delims = ",";
				String tempHomonyms = "";
				System.out.println("Tokenized Text String: " + tokenizedMynText);
				String[] tokens = tokenizedMynText.split(delims);
				//----------------------------------- for temp homonym sentence array-----------------------------------------
				tokensForCorrectHomo = tokenizedMynText.split(delims);
				int tokenCount = tokens.length;
				System.out.println("Length is " + tokenCount);
				for (int count = 0; count < tokenCount; count++) {
					System.out.println("Split Output: " + tokens[count]);
					System.out.println();
					// System.out.println(filePath);
					try {
						br = new BufferedReader(new FileReader(filePath));
						while ((line = br.readLine()) != null) {
							String[] textWords = line.split(" ");
							for (int i = 0; i < textWords.length; i++) {	
								System.out.println();
								System.out.println("token count ==>"+tokens[count]);
								System.out.println(" \n Text word of i  "+i+" "+textWords[i]);
								if (tokens[count].equals(textWords[i])) {
									System.out.println(textWords[i]+ "is homonym word");
									tempHomonyms += " " + textWords[i];
									System.out.println("Temp homony==>"+tempHomonyms);
									if (i >= 1) {
										System.out.println("Another homo"+ textWords[i - 1]);
										anotherHomonymWord = textWords[i - 1];
									} else  if (i==0){
										anotherHomonymWord = textWords[i + 1];
									}
									
									tokensForCorrectHomo[count] = anotherHomonymWord;
									stringForCorrectHomo="";
									for (int j = 0; j < tokensForCorrectHomo.length; j++) {
										stringForCorrectHomo += tokensForCorrectHomo[j];
									}
									System.out.println("Correct homonym sentence :"
													+ stringForCorrectHomo);
								}

							}
						}
					} catch (Exception e2) {
						System.out.println("Errors " + e2);
					}
				}
				String bothHomonymWords = "";
				System.out.println("Another homonym word" + anotherHomonymWord);
				bothHomonymWords = tempHomonyms + " " + anotherHomonymWord;
				// txtHomonymWords.setText(bothHomonymWords);
				txtHomonymWords.setText(tempHomonyms);
				anotherHomonymWord = "";
			}
		});
		btnCheckHomonym.setFont(SWTResourceManager.getFont("Myanmar3", 12,
				SWT.NORMAL));
		btnCheckHomonym.setBounds(565, 173, 144, 53);
		btnCheckHomonym.setText("Check Homonyms");

		txtHomonymWords = new Text(this, SWT.BORDER);
		txtHomonymWords.setFont(SWTResourceManager.getFont("Myanmar3", 12,
				SWT.NORMAL));
		txtHomonymWords.setBounds(180, 127, 367, 41);

		Label lblHomonymWords = new Label(this, SWT.NONE);
		lblHomonymWords.setFont(SWTResourceManager.getFont("Myanmar3", 12,
				SWT.NORMAL));
		lblHomonymWords.setBounds(37, 129, 129, 18);
		lblHomonymWords.setText("Homonym Words");

		Button btnTextClear = new Button(this, SWT.NONE);
		btnTextClear.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				txtInputString.setText("");
				txtTokenizedText.setText("");
				txtSegWords.setText("");
				txtHomonymWords.setText("");
				txtFinalResult.setText("");
				txtNextTokenizeSen.setText("");
				txtSegCorWord.setText("");
			}
		});
		btnTextClear.setText("Text Clear");
		btnTextClear.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		btnTextClear.setBounds(565, 104, 144, 53);
		txtSegWords = new Text(this, SWT.BORDER);
		txtSegWords.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		txtSegWords.setBounds(180, 211, 367, 70);
		Label lblSegmentedWords = new Label(this, SWT.NONE);
		lblSegmentedWords.setText("Segmented Words");
		lblSegmentedWords.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		lblSegmentedWords.setBounds(37, 228, 155, 29);
		Button btnSegWord = new Button(this, SWT.NONE);
		btnSegWord.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String checkSegText=WordTokenAndSegment.wordSegment(txtTokenizedText.getText());
				String segWordResult=WordTokenAndSegment.checkSegTextFun(checkSegText);
				System.out.println("Check Seg Text ==>"+segWordResult);
				tagForWegSeg=WordTokenAndSegment.tempstr.toString();				
				txtSegWords.setText(segWordResult);				
				}
		});

		btnSegWord.setText("Word Segment");
		btnSegWord.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		btnSegWord.setBounds(180, 417, 367, 53);

		txtSegCorWord = new Text(this, SWT.BORDER);
		txtSegCorWord.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		txtSegCorWord.setBounds(180, 286, 367, 70);

		Label lblSegmentedWordsFor = new Label(this, SWT.NONE);
		lblSegmentedWordsFor.setText("Segmented Words for\r\n Correct Homonym");
		lblSegmentedWordsFor.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		lblSegmentedWordsFor.setBounds(10, 286, 168, 58);

		Button btnSegCorWord = new Button(this, SWT.NONE);
		btnSegCorWord.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String checkSegText=WordTokenAndSegment.wordSegment(txtNextTokenizeSen.getText());
				String segWordResult=WordTokenAndSegment.checkSegTextFun(checkSegText);
				System.out.println("Check Seg Text ==>"+segWordResult);
				tagForCorSeg=WordTokenAndSegment.tempstr.toString();
				txtSegCorWord.setText(segWordResult);		
				
				//txtSegCorWord.setText(WordTokenAndSegment.wordSegment(txtNextTokenizeSen.getText()));
				}
		});
		btnSegCorWord.setText("Word Segment Correct Word\r\n");
		btnSegCorWord.setFont(SWTResourceManager.getFont("Myanmar3", 12,
				SWT.NORMAL));
		btnSegCorWord.setBounds(180, 473, 367, 53);

		Button btnTokenCorText = new Button(this, SWT.NONE);
		btnTokenCorText.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {			
//-------------------------------------------------------------------------------------------------
				 String inputSequenceForNextToken="";
				 inputSequenceForNextToken =  stringForCorrectHomo.toString();
				System.out.println("input seq for next ===>"+inputSequenceForNextToken);
				String nexttokenizedText=WordTokenAndSegment.tokenText(inputSequenceForNextToken.toString());
				txtNextTokenizeSen.setText(nexttokenizedText);
				stringForCorrectHomo="";
				inputSequenceForNextToken="";
				}
		});
		btnTokenCorText.setText("Tokenize2");
		btnTokenCorText.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		btnTokenCorText.setBounds(565, 244, 144, 53);

		Button btnResult = new Button(this, SWT.NONE);
		btnResult.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				//float countForCorWrdSen = 0.0f;
				float countForFirstSentence = 0.0f;
				//float countForWrgWrdSen = 0.0f;
				float countForSecondSentence = 0.0f;
				float countForCorPreWord = 0.0f;
				float countForWrgPreWord = 0.0f;
				double probabilityForCorWrdSen = 0.0;
				double probabilityForWrgWrdSen = 0.0;
				//String strForWrdSen = symbolForLexicon.toString();	
				String strForWrdSen = txtSegWords.getText().toString();
				
				
				System.out.println("First sentence ==="+symbolForLexicon.toString());
				System.out.println();
				/*String[] arrForWrdSen = strForWrdSen.split(",");*/
				String[] arrForWrdSen = tagForWegSeg.split(",");
				//String strForCorSen=txtSegCorWord.getText().toString();
				System.out.println("Second sentence==>"+symbolForCorTag.toString());
				String[] arrForCorSen = tagForCorSeg.split(",");
				//String filePath="D:\\NLPworkspace\\NLPToken\\textCorpus.txt";
				String filePath = "D:\\sampleCrpus.txt";
				String line = "";
				List<List<String>> words = new ArrayList<List<String>>();
				List<String> arr = null ;
				// List<String> temp=new ArrayList<String>();
				try {
					BufferedReader br = new BufferedReader(new FileReader(	filePath));
					while ((line = br.readLine()) != null) {
						StringTokenizer token = new StringTokenizer(line, ",");
						arr = new ArrayList<String>();
						while (token.hasMoreTokens()) {
							arr.add(token.nextToken());
						} // inner while
						// temp=arr;
						/*System.out.println("Arr " + arr);
						System.out.println("Words " + words);*/
						// arr.clear();
						words.add(arr);
						System.out.println("Arr One Line ===>"+arr);
						// arr.clear();
					}// external while
					words.add(arr);
					System.out.println(words);

					/*
					 * String txtCrpusArr[]=line.split(",");
					 * if((arrForWrdSen[0].equals(txtCrpusArr[0]))
					 * &&(arrForWrdSen[1].equals(txtCrpusArr[1])) ) {
					 * countForWrgWrdSen+=1; } for (int j = 0; j <
					 * txtCrpusArr.length; j++) {
					 * if(arrForWrdSen[0].contains(txtCrpusArr[j])) {
					 * countForWrgPreWord+=1; } }
					 * 
					 * 
					 * if((arrForCorSen[0].contains(txtCrpusArr[0]))
					 * &&(arrForCorSen[1].contains(txtCrpusArr[1]))) {
					 * countForCorWrdSen+=1; } for (int i = 0; i <
					 * txtCrpusArr.length; i++) {
					 * if(arrForCorSen[0].contains(txtCrpusArr[i])) {
					 * countForCorPreWord+=1; } }
					 */

				}// end try
				
				/*
				 * probabilityForCorWrdSen=countForCorWrdSen/countForCorPreWord;
				 * probabilityForWrgWrdSen=countForWrgWrdSen/countForWrgPreWord;
				 * if(probabilityForCorWrdSen>probabilityForWrgWrdSen) {
				 * txtFinalResult.setText(finalResultForCorSen.toString()); }
				 * else {
				 * txtFinalResult.setText(finalResultForWrgSen.toString()); }
				 */

				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for (int i = 0; i < words.size(); i++) {					
					for (int j = 0; j < words.get(i).size() -1; j++) {
						if(j<words.get(i).size()-1){
							if (((words.get(i).get(j)).contains(arrForCorSen[0]))
									&& ((words.get(i).get(j +1)).contains(arrForCorSen[1]))) {
								countForSecondSentence += 1;
								System.out.println("0 and 1" + arrForCorSen[0] + "   "
										+ arrForCorSen[1] + "======> "
										+ words.get(i).get(j) + "     "
										+ words.get(i).get(j + 1));
								System.out.println("countforsen" + countForSecondSentence);
							}
							/*System.out.println("0 and 1" + arrForCorSen[0] + "   "
									+ arrForCorSen[1] + "======> "
									+ words.get(i).get(j) + "     "
									+ words.get(i).get(j + 1));
							System.out.println("countforsen" + countForSecondSentence);*/
							if (((words.get(i).get(j)).contains(arrForWrdSen[0]))
									&& ((words.get(i).get(j + 1)).contains(arrForWrdSen[1]))) {
								countForFirstSentence += 1;
							}
							System.out.println("0 and 1" + arrForWrdSen[0] + "   "
									+ arrForWrdSen[1] + "=========>"
									+ words.get(i).get(j) + "    "
									+ words.get(i).get(j + 1));
							System.out.println("countforwrgsen" + countForFirstSentence);
						}
						
					}
					for (int j1 = 0; j1 < arr.size(); j1++) {
						if ((words.get(i).get(j1)).contains(arrForCorSen[0])) {
							countForCorPreWord += 1;
						}
						if ((words.get(i).get(j1)).contains(arrForWrdSen[0])) {
							countForWrgPreWord += 1;
						}
					}
				
					}
				System.out.println("count for second word" + countForSecondSentence);
				System.out.println("count for first word" + countForFirstSentence);
				System.out.println("count for correct  pre word"+ countForCorPreWord);
				System.out.println("count for  pre wrong word"+ countForWrgPreWord);

				System.out.println("countForCorword" + countForSecondSentence);
				if(countForCorPreWord>0.0){
					probabilityForCorWrdSen = countForSecondSentence/ countForCorPreWord;
				}else {
					probabilityForCorWrdSen=0.0;
				}
				probabilityForCorWrdSen = countForSecondSentence/ countForCorPreWord;
				System.out.println("correct pro" + countForFirstSentence);
				if(countForWrgPreWord>0.0)
				{
				probabilityForWrgWrdSen = countForFirstSentence/ countForWrgPreWord;
				}else {
					probabilityForWrgWrdSen=0.0;
				}
				System.out.println("Pre ===>"+countForWrgPreWord);
				System.out.println("First sen===>"+countForFirstSentence);
				System.out.println("Probability for correct"+ probabilityForCorWrdSen);
				System.out.println("Probability for wrong "+ probabilityForWrgWrdSen);
				if (probabilityForCorWrdSen > probabilityForWrgWrdSen) {
					txtFinalResult.setText(finalResultForCorSen.toString());
					System.out.println("Correct sen"+finalResultForCorSen.toString());
				} else {
					txtFinalResult.setText(finalResultForWrgSen.toString());
				}
			}
		});
		btnResult.setText("Result");
		btnResult.setFont(SWTResourceManager.getFont("Myanmar3", 12, SWT.NORMAL));
		btnResult.setBounds(565, 303, 144, 53);

		Label label = new Label(this, SWT.NONE);
		label.setText("Tokenized Text1");
		label.setFont(SWTResourceManager.getFont("Myanmar3", 12, SWT.NORMAL));
		label.setBounds(37, 182, 129, 29);

		txtNextTokenizeSen = new Text(this, SWT.BORDER);
		txtNextTokenizeSen.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		txtNextTokenizeSen.setBounds(180, 173, 367, 35);

		txtFinalResult = new Text(this, SWT.BORDER);
		txtFinalResult.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		txtFinalResult.setBounds(180, 362, 367, 41);

		Label lblFinalResult = new Label(this, SWT.NONE);
		lblFinalResult.setText("Final Result");
		lblFinalResult.setFont(SWTResourceManager.getFont("Myanmar3", 12,SWT.NORMAL));
		lblFinalResult.setBounds(63, 365, 129, 18);
		createContents();
	}

	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("Input String");
		setSize(829, 589);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
