import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

	public class WordTokenAndSegment {
	// correct final tokenization
	static String segSeq = "";
	public static String tempstr="";
	static String resultText = "";
	static String letterSeq = "";
	static String input="ကျောင်းအုပ်ဆရာကြီးသည်ကျောင်းသို့သွားသည်";
	//static String input ="လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	//= "လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	static String letterSeq1 = "", letterSeq2 = "", letterSeq3 = "";
	static String input1 = "", input2 = "", input3 = "";
	public static void main(String args[])
	{
		tokenText(input);
		String tokenizedText="သစ်,ကိုင်း,ကျိုး,နေ,သည်";
		String result=wordSegment(tokenizedText);
		System.out.println("Word Segment =="+result);
		//String checkSegText="စုစု[NPR],သည်[POVP],ကျောင်း[NCCS],သို့[PODIR],သွား[NCCS],သည်[PONOM],။[SM]";
		//String resultForCheckSegWord=
		String checkSegText=result;
				checkSegTextFun(checkSegText);
		//System.out.println("Checked Segment Word ====>"+resultForCheckSegWord);
	}
	public static String tokenText(String textInput) {
		// TODO Auto-generated method stub
		segSeq = "";
		 resultText = "";
		letterSeq = "";
		 letterSeq1 = "";
		 letterSeq2 = "";
		 letterSeq3 = "";
		 input1 = "";
		 input2 = "";
		 input3 = "";
		int[][] twoConsecutive = { 
				{ -1, 9, 1, 1, 0, -1, 1, 0, 1, 0, 0, 1, 1 }, 
				{ 0, 9, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1 },
				{ -1, 1, 0, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 9, 1, 1, 2, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 9, 1, 1, 0, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 1, 1, 1, 0, -1, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ 2, 9, 1, 1, 0, 0, 1, 0, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1 },
				{ 2, 9, 1, 1, 0, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 0, 1 } };			
		String C = "ကခဂဃငစဆဇဈဉညဋဌဍဎဏတထဒဓနပဖဗဘမယရလဝသဟဠအ";
		String M = "ျြွှ";
		String V = "ါာိီုူေဲ";
		String S = "္";
		String A = "်";
		String F = "ံ့း";
		String I = "ဤဧဪ၌၍၏";
		String E = "ဣဥဦဩ၎";
		String G = "ဿ";
		String D = "၀၁၂၃၄၅၆၇၈၉";
		String P = "၊။";
		String W = " ";
		int i, j;
		for (i = 0; i < textInput.length(); i++) {
			for (j = 0; j < C.length(); j++) {
				if (textInput.charAt(i) == C.charAt(j))
					letterSeq = letterSeq + "C";
			}
			for (j = 0; j < M.length(); j++) {
				if (textInput.charAt(i) == M.charAt(j))
					letterSeq = letterSeq + "M";
			}
			for (j = 0; j < V.length(); j++) {
				if (textInput.charAt(i) == V.charAt(j))
					letterSeq = letterSeq + "V";
			}
			for (j = 0; j < S.length(); j++) {
				if (textInput.charAt(i) == S.charAt(j))
					letterSeq = letterSeq + "S";
			}
			for (j = 0; j < A.length(); j++) {
				if (textInput.charAt(i) == A.charAt(j))
					letterSeq = letterSeq + "A";
			}
			for (j = 0; j < I.length(); j++) {
				if (textInput.charAt(i) == I.charAt(j))
					letterSeq = letterSeq + "I";
			}
			for (j = 0; j < F.length(); j++) {
				if (textInput.charAt(i) == F.charAt(j))
					letterSeq = letterSeq + "F";
			}
			for (j = 0; j < E.length(); j++) {
				if (textInput.charAt(i) == E.charAt(j))
					letterSeq = letterSeq + "E";
			}
			for (j = 0; j < G.length(); j++) {
				if (textInput.charAt(i) == G.charAt(j))
					letterSeq = letterSeq + "G";
			}
			for (j = 0; j < D.length(); j++) {
				if (input.charAt(i) == D.charAt(j))
					letterSeq = letterSeq + "D";
			}
			for (j = 0; j < P.length(); j++) {
				if (textInput.charAt(i) == P.charAt(j))
					letterSeq = letterSeq + "P";
			}
			for (j = 0; j < W.length(); j++) {
				if (textInput.charAt(i) == W.charAt(j))
					letterSeq = letterSeq + "W";
			}
		}
		letterSeq = letterSeq + "#";
		System.out.println("Input String:  \t"+input);
		System.out.println("Letter Sequence:  \t " + letterSeq);
		int[] convert = new int[letterSeq.length()];
		for (i = 0; i < letterSeq.length(); i++) {
			switch (letterSeq.charAt(i)) {
			case 'A':
				convert[i] = 0;
				break;
			case 'C':
				convert[i] = 1;
				break;
			case 'D':
				convert[i] = 2;
				break;
			case 'E':
				convert[i] = 3;
				break;
			case 'F':
				convert[i] = 4;
				break;
			case 'G':
				convert[i] = 5;
				break;
			case 'I':
				convert[i] = 6;
				break;
			case 'M':
				convert[i] = 7;
				break;
			case 'P':
				convert[i] = 8;
				break;
			case 'S':
				convert[i] = 9;
				break;
			case 'V':
				convert[i] = 10;
				break;
			case 'W':
				convert[i] = 11;
				break;
			case '#':
				convert[i] = 12;
				break;
			}
			
		}
		System.out.println("No. of inputString:   ");
		for (i = 0; i < convert.length; i++) {
			System.out.print(convert[i] + " \t ");
		}
		int row, col = 0; //For Table-1 Matrix
		
		for (i = 0; i < convert.length - 1; i++) {
			row = convert[i];
			col = convert[i + 1];
			System.out.println("Row====="+row);
			System.out.println("Col====="+col);
			
			switch (twoConsecutive[row][col]) {
			case 0:
				/*segSeq = segSeq + letterSeq.charAt(i);
				resultText = resultText + input.charAt(i);
				letterSeq1 = letterSeq.substring(i);
				input1 = input.substring(i);
				System.out.println(" \n Segmented sequence :"+segSeq);
				System.out.println("Result text : \t"+resultText);
				System.out.println("\n Input 1 \t"+input1);
				System.out.println("Letter sequence1 "+letterSeq1);
				
				break;*/
				segSeq += letterSeq.charAt(i);
				resultText += textInput.charAt(i);
				letterSeq1 = letterSeq.substring(i+1);
				System.out.println(segSeq);

				System.out.println(resultText);

				System.out.println("Leave of the LetterSequence" + letterSeq1);
				System.out.println();

				input1 = textInput.substring(i+1);
				System.out.println("Leave of the Input Sequence " + input1);
				System.out.println();
				break;
				
			case 1:
				System.out.println("col = "+convert[i + 1]);
				System.out.println("row="+convert[i]);
				segSeq = segSeq + letterSeq.charAt(i) + ",";
				resultText = resultText + textInput.charAt(i) + ",";
				System.out.println("\n Segment Sequence:== \t"+segSeq);
				System.out.println("\n Result Text: \t"+resultText);
				break;
			case 2:
				segSeq = segSeq + letterSeq.charAt(i);
				resultText = resultText + textInput.charAt(i);
				break;
			case 9:	// 9 is equal to U
				letterSeq1 = letterSeq.substring(i);
				input1 = textInput.substring(i);
				String twoChar = String.valueOf(letterSeq.charAt(i))
						+ String.valueOf(letterSeq.charAt(i + 1));
				secondTable(convert[i + 2], twoChar, i, convert);
				System.out.println("Letter Sequence1 : \t"+letterSeq1);
				System.out.println("Input 1: \t"+input1);
				System.out.println("Two Character : \t "+twoChar);
				break;
			}
			
			
			//System.out.println(" \n Result Text " + i + " : " + resultText);
			
	
		}
		return resultText;
		
	}
	
	
		
		static void secondTable(int c, String s, int i, int[] convert) {
				int a = 0;
				int j = 0;
				int[][] threeConsecutive = { { 3, 1, 1, 1, 1, 1, 1, 9, 1, 1, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 3, 1, 1, 1, 1, 1, 1, 9, 1, 1, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 9, 1, 0, 1, 1, 1 } }; // Define the end of each row is add one (1) 
			
				if (s.equals("AC"))			a = 0;
						else if (s.equals("CC"))		a = 1;
								else if (s.equals("EC"))				a = 2;
										else if (s.equals("FC"))			a = 3;
											else if (s.equals("MC"))		a = 4;
												else if (s.equals("VC")) 		a = 5;
			
			switch (threeConsecutive[a][c]) {
						case 0	:	segSeq = segSeq + letterSeq1.charAt(0);
										resultText = resultText + input1.charAt(0);
										System.out.println("Segment sequence : "+segSeq);
										System.out.println("Segment myanmar sequence:"+resultText);
										break;
						case 1	:	segSeq = segSeq + letterSeq1.charAt(0) + ",";
										resultText = resultText + input1.charAt(0) + ",";
										System.out.println("Segment sequence :==== "+segSeq);
										System.out.println("Segment myanmar sequence:==="+resultText);
										break;
						case 9	:	letterSeq2 = letterSeq1.substring(j);
										input2 = input1.substring(j);
										String threeChars = s + String.valueOf(letterSeq2.charAt(2));
										thirdTable(convert[i + 3], threeChars, i, convert);
										System.out.println("Letter sequence2 : "+letterSeq2);
										System.out.println("Input myanmar sequence2:"+input2);
										System.out.println("Three Characters:"+threeChars);
										break;
			}
		}
		static void thirdTable(int c, String s1, int i, int[] convert) {
			
				int a = 0;
				int[][] fourConsecutive = { { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
														{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
														{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

				if (s1.equals("ACM"))		a = 0;
					else if (s1.equals("FCM"))	a = 1;
						else if (s1.equals("VCM"))	a = 2;
			
				switch (fourConsecutive[a][c]) {
						case 0	:	segSeq = segSeq + letterSeq1.charAt(0);
										resultText = resultText + input1.charAt(0);
										break;
						case 1	:	segSeq = segSeq + letterSeq1.charAt(0) + ",";
										resultText = resultText + input1.charAt(0) + ",";
										break;
			}
			
		} //End of thirdTable function

	public static String wordSegment(String tokenizedText){
		String returnText="";
		List<String> lexicon = new ArrayList<String>();
		FileInputStream file = null;
		 //String tempstr="";
		 String symbolForLexicon="";
		 String resultSequenceForFrstToken="";
		 List<String> string = new ArrayList<String>();
		 List<String> lastOutput = new ArrayList<String>();
		 String finalResultForWrgSen="";			
		try {
			tempstr="";
			file = new FileInputStream("D:\\NLPworkspace\\NLPToken\\lexicon-1.txt");
			InputStreamReader ins = new InputStreamReader(file, Charset.forName("UTF-8"));
			BufferedReader bufferreader = new BufferedReader(ins);
			String line;
			while ((line = bufferreader.readLine()) != null) {
				StringTokenizer tok = new StringTokenizer(line, "\t");
				while (tok.hasMoreTokens()) {
					lexicon.add(tok.nextToken());
				}
				System.out.println("Each line");
			}
			System.out.println("Each line" + line);
			List<String> myanmarPhrase = new ArrayList<String>();
			for (int index = 1; index < lexicon.size(); index += 6) {
				System.out.println("index =" + index);
				myanmarPhrase.add(lexicon.get(index));
			}
			for (String s : myanmarPhrase) {
				System.out.println("Mynamar Pharse :" + s);
			}
			resultSequenceForFrstToken =tokenizedText;
			
			StringTokenizer token = new StringTokenizer(resultSequenceForFrstToken,	",");
			while (token.hasMoreTokens()) {
				string.add(token.nextToken());
			}
			System.out.println(string);
			int size = string.size();
			System.out.println("Original size " + size);
			while (size > 0) {
				for (int k = string.size(); k > 0; k--) {
					boolean flag = false;
					String str = "";
					List<String> sub = new ArrayList<String>(string.subList(0, k));
					System.out.println("Sub  "+sub);
					for (int s = 0; s < sub.size(); s++) {
						str = str.concat(sub.get(s));
						// i define
						System.out.println("String concat" + str);
					}
					for (int a = 0; a < myanmarPhrase.size(); a++) {
						if (str.equals(myanmarPhrase.get(a))) {
							System.out.println("Equ");
							lastOutput.add(str);
							flag = true;
							System.out.println(k);
							if (k > 1) {
								for (int b = 1; b <= k; b++) {
									string.remove(k - b);
								}
							} else {
								string.remove(k - 1);
							}
							System.out.println("Remove k elements "
									+ string + "\t" + string.size());
							break;
						}
					}
					if (!flag) {
						System.out.println("Zero " + str);
						if (k == 1) {
							lastOutput.add(str);
							string.remove(k - 1);
							break;
						}
					} else {
						break;
					}
				}
				size = string.size();
			}
			System.out.println("Final Segmentation  "	+ lastOutput.toString());
			finalResultForWrgSen = lastOutput.toString();
			for (int z = 0; z < lastOutput.size(); z++) {
				for (int x = 0; x < lexicon.size(); x += 6) {
					if (lastOutput.get(z).equals(lexicon.get(x + 1))) {
						// System.out.println("Tag "+lexicon.get(x+4));
						lastOutput.set(z,lastOutput.get(z).concat("[" + lexicon.get(x + 4))+ "]");
						tempstr = tempstr.concat("["	+ lexicon.get(x + 4).toString() + "],");
						System.out.println("Tag Only===>"+tempstr.toString());
					}
				}
			}
			System.out.println("Tag Only===>"+tempstr.toString());
			 symbolForLexicon = tempstr.toString();
			System.out.println("Taggggg Add " + lastOutput);
			System.out.println("Tag gggggggggggg" + symbolForLexicon);
			returnText=lastOutput.toString();
		}

		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		// FileInputStream file=new
		// FileInputStream("D:\\sampleCrpus.txt");
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	
		return returnText;
	}
	public static String checkSegTextFun(String checkSegText) {
		// TODO Auto-generated method stub
		List<String> segWordLst=new ArrayList<String>();
		StringTokenizer token=new StringTokenizer(checkSegText,",");
		while(token.hasMoreTokens()){
		 segWordLst.add(token.nextToken());
		}
		String tempstr2="";
		for(int i=0;i<segWordLst.size();i++){
			//------to define sentence marker and သည် (POVP)-------------------------------
			System.out.println("segWordlst"+i+"==>"+segWordLst.get(i)+" contains SM");
			if(segWordLst.get(i).contains("[SM]")){
				String tempstr=segWordLst.get(i-1);
				if(tempstr.contains("[PONOM]")){
					tempstr2=tempstr.replace("[PONOM]", "[POVP]");					
					segWordLst.remove(i-1);
					segWordLst.add(i-1,tempstr2);
					//segWordLst.get(i-1)=segWordLst.get(i-1).replace("[PONOM]", "[POVP]");
				}
					segWordLst.get(i-1).replace("[POVP]", "[PONOM]");			
					System.out.println("SegWordLst(i-1) ====>"+segWordLst.get(i-1));
			
			}
			//---------------------------------------------------------------------
			//------for disambiguating သွား verb or noun--------------------
			if(segWordLst.get(i).contains("သွား")){
				if((segWordLst.get(i+1).contains("ကို")) ){
					segWordLst.get(i).replace("[VAC]", "[NCCS]");					
				}
				if(i>=1){
					if(segWordLst.get(i-1).contains("၏")){
						segWordLst.get(i).replace("[VAC]", "[NCCS]");							
					}
				}
			}
			
			//---------------------------------to define သည်(PONOM) after Noun----------------------------------------
			if(i>0){
				if(segWordLst.get(i).contains("[POVP]")){
					String tempstr=segWordLst.get(i-1);
					String strForPoNom=segWordLst.get(i);
					if(tempstr.contains("[NCCS]") || tempstr.contains("[NCCP]")
				|| tempstr.contains("[NCU]") || tempstr.contains("[NPR]")){
						String tempstr1=strForPoNom.replace("[POVP]", "[PONOM]");		
						System.out.println("Tempstr1===>"+tempstr);
						segWordLst.remove(i);
						segWordLst.add(i,tempstr1);
						//segWordLst.get(i-1)=segWordLst.get(i-1).replace("[PONOM]", "[POVP]");
					}
						/*segWordLst.get(i-1).replace("[POVP]", "[PONOM]");		*/	
						System.out.println("SegWordLst(i) ====>"+segWordLst.get(i));
				
				}
				
				
				
			}
			//------------------------------------------------------------------------
			if(i>0){
				if(segWordLst.get(i).contains("၏")){
					String tempstr=segWordLst.get(i-1);
					String strForPoNom=segWordLst.get(i);
					if(tempstr.contains("[NCCS]") || tempstr.contains("[NCCP]") || tempstr.contains("[NCPS]")
				|| tempstr.contains("[NCU]") || tempstr.contains("[NPR]") || tempstr.contains("[PRSP]")
				|| tempstr.contains("[PRL]") || tempstr.contains("[PRO]") ){
						segWordLst.remove(i);
						String strPOPOs="၏[POPOS]";
						segWordLst.add(i,strPOPOs);
						//String tempstr1=strForPoNom.replace("[POVP]", "[PONOM]");		
						System.out.println("Tempstr1===>"+tempstr);
						/*segWordLst.remove(i);
						segWordLst.add(i,tempstr1);*/
						//segWordLst.get(i-1)=segWordLst.get(i-1).replace("[PONOM]", "[POVP]");
					}
						/*segWordLst.get(i-1).replace("[POVP]", "[PONOM]");		*/	
						System.out.println("SegWordLst(i) ====>"+segWordLst.get(i));
				
				}
			}
			//-------------------------------------------------------------------------
			if(segWordLst.get(i).contains("သွား") && segWordLst.get(i).contains("[NCCS]")){
					if((segWordLst.get(i+1).contains("သည်")) || ((segWordLst.get(i+1).contains("နေ"))) ||
							((segWordLst.get(i+1).contains("ပြီ"))) ||  ((segWordLst.get(i+1).contains("ပြီး")))
							|| ((segWordLst.get(i+1).contains("၍"))) || ((segWordLst.get(i+1).contains("၏")))){
						String str=segWordLst.get(i);
						String replaceStr=str.replace("[NCCS]", "[VAC]");
						segWordLst.remove(i);
						segWordLst.add(i,replaceStr);
				}
			}
		
			if(segWordLst.get(i).contains("သွား")){
				if((segWordLst.get(i+1).contains("ကို")) ){
					String str=segWordLst.get(i);
					String replaceStr=segWordLst.get(i).replace("[VAC]", "[NCCS]");		
					segWordLst.remove(i);
					segWordLst.add(i,replaceStr);
				}
		}
		}
		
		//------------------------------------------------------------------------------
		String result="";
		for(int j=0;j<segWordLst.size();j++){
			result+= segWordLst.get(j)+",";
		}
		System.out.println("Result ====>"+result);
		return result;
	}
	
	
	}
	


