package java.util.stream;

public class Stream {

}
