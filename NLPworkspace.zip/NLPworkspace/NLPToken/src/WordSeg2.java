import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

//import edu.stanford.nlp.io.EncodingPrintWriter.out;

public class WordSeg2 
{
	static String segSequence = "";
	static String resultSequence = "";
	static String letterSequence = "";
	//static String inputSequence = "မြန်မာစာစကားသည်အရေးပါသည်";
	static String inputSequence = "သစ်ကိုင်းကြိုးနေသည်";
	
	static String letterSeq1, letterSeq2, letterSeq3;
	static String inputSeq1 = "";
	private static int[] convertArr = null;


	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException 
	{
		List<String> lexicon=new ArrayList<String>();
		FileInputStream file=new FileInputStream("D:\\NLPworkspace\\NLPToken\\lexicon-1.txt");
		//FileInputStream file=new FileInputStream("D:\\sampleCrpus.txt");
		InputStreamReader ins=new InputStreamReader(file,Charset.forName("UTF-8"));
		BufferedReader bufferreader=new BufferedReader(ins);
		String line;
		while((line=bufferreader.readLine())!=null)
		{
		StringTokenizer tok=new StringTokenizer(line,"\t");
			while(tok.hasMoreTokens())
			{
				lexicon.add(tok.nextToken());
			}
			System.out.println("Each line");
			
		}
	//	System.out.println("Each line"+line);
		List<String> myanmarPhrase=new ArrayList<String>();
		for(int index=1;index<lexicon.size();index+=6)
		{
			myanmarPhrase.add(lexicon.get(index));
		}
		for(String s:myanmarPhrase)
		{
			System.out.println(s);
		}
		int TwoConsecutiveArr[][] = {
				{ -1, 7, 1, 1, 0, -1, 1, 0, 1, 0, 0, 1, 1 },
				{ 0, 7, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1 },
				{ -1, 1, 0, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 7, 1, 1, 2, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 7, 1, 1, 2, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 1, 1, 1, 0, -1, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ 2, 7, 1, 1, 0, 0, 1, 0, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1 },
				{ 2, 7, 1, 1, 0, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 0, 1 } };

		String C = "ကခဂဃငစဆဇဈညဋဌဍဎဏတထဒဓနပဖဗဘမယရလ၀သဟဠအ";

		String M = "ျြွှ";

		String V = "ါာိီုူေဲ";

		String S = "္";

		String A = "်";

		String F = "ံ့း";

		String I = "ဤ၏ဧဪ၌၍";

		String E = "ဥဦဣဩ၎";

		String G = "ဿ";

		String D = "၀၁၂၃၄၅၆၇၈၉";

		String P = "၊။";

		String W = " ";

		int i, j;
		System.out.println("input text is " + inputSequence);

		System.out.println("input text length is" + inputSequence.length());
		letterSequence="";
		segSequence="";
		resultSequence="";
		for (i = 0; i < inputSequence.length(); i++) {
			System.out.println("input sequenc of " + i + "="
					+ inputSequence.charAt(i));
			for (j = 0; j < C.length(); j++) {
				if (inputSequence.charAt(i) == C.charAt(j)) {
					letterSequence += "C";
				}
			}
			for (j = 0; j < M.length(); j++) {
				if (inputSequence.charAt(i) == M.charAt(j)) {
					letterSequence += "M";
				}
			}
			for (j = 0; j < V.length(); j++) {
				if (inputSequence.charAt(i) == V.charAt(j)) {
					letterSequence += "V";
				}
			}
			for (j = 0; j < S.length(); j++) {
				if (inputSequence.charAt(i) == S.charAt(j)) {
					letterSequence += "S";
				}
			}
			for (j = 0; j < A.length(); j++) 
			{
				if (inputSequence.charAt(i) == A.charAt(j)) 
				{
					letterSequence += "A";
				}
			}

			for (j = 0; j < F.length(); j++) {
				if (inputSequence.charAt(i) == F.charAt(j)) {
					letterSequence += "F";
				}
			}

			for (j = 0; j < I.length(); j++) {
				if (inputSequence.charAt(i) == I.charAt(j)) {
					letterSequence += "I";
				}
			}

			for (j = 0; j < E.length(); j++) {
				if (inputSequence.charAt(i) == E.charAt(j)) {
					letterSequence += "E";
				}
			}

			for (j = 0; j < G.length(); j++) {
				if (inputSequence.charAt(i) == G.charAt(j)) {
					letterSequence += "G";
				}
			}

			for (j = 0; j < D.length(); j++) {
				if (inputSequence.charAt(i) == D.charAt(j)) {
					letterSequence += "D";
				}
			}

			for (j = 0; j < P.length(); j++) {
				if (inputSequence.charAt(i) == P.charAt(j)) {
					letterSequence += "P";
				}
			}

			for (j = 0; j < W.length(); j++) {
				if (inputSequence.charAt(i) == W.charAt(j)) {
					letterSequence += "A";
				}
			}

		}
		letterSequence += "#";

		System.out.println("Letter Sequence :" + letterSequence);
		System.out.println();

		convertArr = new int[letterSequence.length() + 6];
		System.out.println("Convert length =" + convertArr.length);
		for (i = 0; i < letterSequence.length(); i++) {
			switch (letterSequence.charAt(i)) {
			case 'A':
				convertArr[i] = 0;
				break;

			case 'C':
				convertArr[i] = 1;
				break;

			case 'D':
				convertArr[i] = 2;
				break;

			case 'E':
				convertArr[i] = 3;
				break;

			case 'F':
				convertArr[i] = 4;
				break;

			case 'G':
				convertArr[i] = 5;
				break;

			case 'I':
				convertArr[i] = 6;
				break;

			case 'M':
				convertArr[i] = 7;
				break;

			case 'P':
				convertArr[i] = 8;
				break;

			case 'S':
				convertArr[i] = 9;
				break;

			case 'V':
				convertArr[i] = 10;
				break;

			case 'W':
				convertArr[i] = 11;
				break;

			case '#':
				convertArr[i] = 12;
				break;

			}
		}

		System.out.println("No. of inputString:   ");
		for (i = 0; i < convertArr.length; i++) 
		{
			System.out.print(convertArr[i] + "  ");
		}

		System.out.println();

		int row = 0, col = 0;
		for (i = 0; i < convertArr.length - 7; i++) {
			row = convertArr[i];
			col = convertArr[i + 1];

			switch (TwoConsecutiveArr[row][col]) {
			case 0:
				segSequence += letterSequence.charAt(i);
				resultSequence += inputSequence.charAt(i);
				letterSeq1 = letterSequence.substring(i);
				System.out.println(segSequence);

				System.out.println(resultSequence);

				System.out.println("Leave of the LetterSequence" + letterSeq1);
				System.out.println();

				inputSeq1 = inputSequence.substring(i);
				System.out.println("Leave of the Input Sequence " + inputSeq1);
				System.out.println();
				break;

			case 1:
				segSequence = segSequence + letterSequence.charAt(i) + "#";
				resultSequence = resultSequence + inputSequence.charAt(i) + ",";
				break;

			case 2:
				segSequence = segSequence + letterSequence.charAt(i);
				resultSequence = resultSequence + inputSequence.charAt(i);
				break;

			case 7:
				letterSeq1 = letterSequence.substring(i);
				System.out.println("Substring of Letter Sequence: "
						+ letterSeq1);
				System.out.println();

				inputSeq1 = inputSequence.substring(i);
				System.out.println("Leave of the Input Sequence " + inputSeq1);
				System.out.println();
			
				String twoCharacters = String.valueOf(letterSequence.charAt(i))
						+ String.valueOf(letterSequence.charAt(i + 1));
				System.out.println("Two Character of Letter Sequence"
						+ twoCharacters);
				System.out.println();

				SecondConsecutiveTable(convertArr[i + 2], twoCharacters, i);
				break;

			}
		}

		System.out.println("Tokenized Letter Sequence :" + segSequence);
		System.out.println();
		System.out.println("Tokenized Resulted Sequence :" + resultSequence);
		System.out.println();
		
		List<String> string=new ArrayList<String>();
		List<String> lastOutput=new ArrayList<String>();
		StringTokenizer token=new StringTokenizer(resultSequence,",");
		while(token.hasMoreTokens())
		{
			string.add(token.nextToken());
		}
		System.out.println(string);
		int size=string.size();
		System.out.println("Original size "+size);
		while(size>0)
		{
			for(int k=string.size();k>0;k--)
			{
				boolean flag=false;
				String str="";
				List<String> sub=new ArrayList<String>(string.subList(0, k));
				System.out.println(sub);
				for(int s=0;s<sub.size();s++)
				{
					str=str.concat(sub.get(s));
					//i define
					System.out.println("String concat"+str);
				
				}
				for(int a=0;a<myanmarPhrase.size();a++)
				{
					if(str.equals(myanmarPhrase.get(a)))
					{
						System.out.println("Equ");
						lastOutput.add(str);
						flag=true;
						System.out.println(k);
						if(k>1)
						{
							for(int b=1;b<=k;b++)
							{
								string.remove(k-b);
							}
						}
						else
						{
							string.remove(k-1);
						}
						System.out.println("Remove k elements "+string+"\t"+string.size());
						break;
					}
				}
				if(!flag)
				{
					System.out.println("Zero "+str);
					if(k==1)
					{
						lastOutput.add(str);
						string.remove(k-1);
						break;
					}
				}
				else{break;}
			}	
			size=string.size();
		}
		System.out.println("Final Segmentation  "+lastOutput);
		for(int z=0;z<lastOutput.size();z++)
		{
			for(int x=0;x<lexicon.size();x+=6)
			{
				if(lastOutput.get(z).equals(lexicon.get(x+1)))
				{
					System.out.println("Tag "+lexicon.get(x+4));
					lastOutput.set(z, lastOutput.get(z).concat("["+lexicon.get(x+4))+"]");
				}
			}
		}
		System.out.println("Tag Add "+lastOutput);
	}

	private static void SecondConsecutiveTable(int col, String str, int i) {
		int row = 0;
		int[][] threeConsecutiveArr = {
				{ 3, 1, 1, 1, 1, 1, 1, 7, 1, 1, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 3, 1, 1, 1, 1, 1, 1, 7, 1, 1, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 7, 1, 0, 1, 1, 1 } };
		if (str.equals("AC"))
			row = 0;

		else if (str.equals("CC"))
			row = 1;

		else if (str.equals("EC"))
			row = 2;

		else if (str.equals("FC"))
			row = 3;

		else if (str.equals("MC"))
			row = 4;

		else if (str.equals("VC"))
			row = 5;

		System.out.println("Row is " + row);
		System.out.println();
		System.out.println("Column is " + col);

		switch (threeConsecutiveArr[row][col]) {
		case 0:
			segSequence += str.charAt(0);
			resultSequence += inputSequence.charAt(i);
			break;

		case 1:
			segSequence += str.charAt(0) + "#";
			resultSequence += inputSequence.charAt(i) + ",";
			break;

		case 7:

			String threeCharacters = String.valueOf(letterSequence.charAt(i))
					+ String.valueOf(letterSequence.charAt(i + 1)
							+ String.valueOf(letterSequence.charAt(i + 2)));
			System.out.println("Three Characters of Letter Sequence"
					+ threeCharacters);

			ThreeConsecutiveTable(convertArr[i + 3], threeCharacters, i);
			break;

		}

	}
	private static void ThreeConsecutiveTable(int column, 
			String str, int i) 
	{
		int row = 0;
		int[][] fourConsecutiveArr = {
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };
		if (str.equals("ACM"))
			row = 0;

		else if (str.equals("FCM"))
			row = 1;

		else if (str.equals("VCM"))
			row = 2;
		switch (fourConsecutiveArr[row][column]) 
		{
		case 1:
			segSequence += str.charAt(0) + "#";
			resultSequence += inputSequence.charAt(i) + ",";
			break;
		}
	}
}
