import java.util.ArrayList;
import java.util.List;

public class ArrayListTest {

	public static void main(String[] args) {

		List<String> listA = new ArrayList<String>();
		listA.add("A");

		List<String> listB = new ArrayList<String>();
		listB.add("B");

		List<List<String> >listFinal = new ArrayList<List<String>>();
	//	listFinal.add(listA);
		//listFinal.add(listB);

		//same result
		//List<List<String> listFinal = new ArrayList<String>(listA);
		//listFinal.addAll(listB);
		
		for (int j = 0; j < 3; j++) 
		{
			for (int i = 0; i < 3; i++) 
			{
			//	listB.add("b"+i);
				listA.add("a"+i);
				
			}
			listFinal.add(listA);
			//listFinal.add(listB);
			
		}
		

		System.out.println("listA : " + listA);
		System.out.println("listB : " + listB);
		System.out.println("listFinal : " + listFinal);

	}

}
