	public class TestToken {
	// correct final tokenization
	static String segSeq = "";
	static String resultText = "";
	static String letterSeq = "";
	static String input="မြန်မာ";
	//static String input ="လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	//= "လူတိုင်းသည် တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";
	static String letterSeq1 = "", letterSeq2 = "", letterSeq3 = "";
	static String input1 = "", input2 = "", input3 = "";
	public static void main(String args[])
	{
			int[][] twoConsecutive = { 
					{ -1, 9, 1, 1, 0, -1, 1, 0, 1, 0, 0, 1, 1 }, 
					{ 0, 9, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1 },
					{ -1, 1, 0, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
					{ -1, 9, 1, 1, 2, 0, 1, -1, 1, -1, 0, 1, 1 },
					{ -1, 9, 1, 1, 0, -1, 1, -1, 1, -1, -1, 1, 1 },
					{ -1, 1, 1, 1, 0, -1, 1, -1, 1, -1, 0, 1, 1 },
					{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
					{ 2, 9, 1, 1, 0, 0, 1, 0, 1, -1, 0, 1, 1 },
					{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
					{ -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1 },
					{ 2, 9, 1, 1, 0, 0, 1, -1, 1, -1, 0, 1, 1 },
					{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 0, 1 } };			
			String C = "ကခဂဃငစဆဇဈဉညဋဌဍဎဏတထဒဓနပဖဗဘမယရလဝသဟဠအ";
			String M = "ျြွှ";
			String V = "ါာိီုူေဲ";
			String S = "္";
			String A = "်";
			String F = "ံ့း";
			String I = "ဤဧဪ၌၍၏";
			String E = "ဣဥဦဩ၎";
			String G = "ဿ";
			String D = "၀၁၂၃၄၅၆၇၈၉";
			String P = "၊။";
			String W = " ";
			int i, j;
			for (i = 0; i < input.length(); i++) {
				for (j = 0; j < C.length(); j++) {
					if (input.charAt(i) == C.charAt(j))
						letterSeq = letterSeq + "C";
				}
				for (j = 0; j < M.length(); j++) {
					if (input.charAt(i) == M.charAt(j))
						letterSeq = letterSeq + "M";
				}
				for (j = 0; j < V.length(); j++) {
					if (input.charAt(i) == V.charAt(j))
						letterSeq = letterSeq + "V";
				}
				for (j = 0; j < S.length(); j++) {
					if (input.charAt(i) == S.charAt(j))
						letterSeq = letterSeq + "S";
				}
				for (j = 0; j < A.length(); j++) {
					if (input.charAt(i) == A.charAt(j))
						letterSeq = letterSeq + "A";
				}
				for (j = 0; j < I.length(); j++) {
					if (input.charAt(i) == I.charAt(j))
						letterSeq = letterSeq + "I";
				}
				for (j = 0; j < F.length(); j++) {
					if (input.charAt(i) == F.charAt(j))
						letterSeq = letterSeq + "F";
				}
				for (j = 0; j < E.length(); j++) {
					if (input.charAt(i) == E.charAt(j))
						letterSeq = letterSeq + "E";
				}
				for (j = 0; j < G.length(); j++) {
					if (input.charAt(i) == G.charAt(j))
						letterSeq = letterSeq + "G";
				}
				for (j = 0; j < D.length(); j++) {
					if (input.charAt(i) == D.charAt(j))
						letterSeq = letterSeq + "D";
				}
				for (j = 0; j < P.length(); j++) {
					if (input.charAt(i) == P.charAt(j))
						letterSeq = letterSeq + "P";
				}
				for (j = 0; j < W.length(); j++) {
					if (input.charAt(i) == W.charAt(j))
						letterSeq = letterSeq + "W";
				}
			}
			letterSeq = letterSeq + "#";
			System.out.println("Input String:  \t"+input);
			System.out.println("Letter Sequence:  \t " + letterSeq);
			int[] convert = new int[letterSeq.length()];
			for (i = 0; i < letterSeq.length(); i++) {
				switch (letterSeq.charAt(i)) {
				case 'A':
					convert[i] = 0;
					break;
				case 'C':
					convert[i] = 1;
					break;
				case 'D':
					convert[i] = 2;
					break;
				case 'E':
					convert[i] = 3;
					break;
				case 'F':
					convert[i] = 4;
					break;
				case 'G':
					convert[i] = 5;
					break;
				case 'I':
					convert[i] = 6;
					break;
				case 'M':
					convert[i] = 7;
					break;
				case 'P':
					convert[i] = 8;
					break;
				case 'S':
					convert[i] = 9;
					break;
				case 'V':
					convert[i] = 10;
					break;
				case 'W':
					convert[i] = 11;
					break;
				case '#':
					convert[i] = 12;
					break;
				}
				
			}
			System.out.println("No. of inputString:   ");
			for (i = 0; i < convert.length; i++) {
				System.out.print(convert[i] + " \t ");
			}
			int row, col = 0; //For Table-1 Matrix
			
			for (i = 0; i < convert.length - 1; i++) {
				row = convert[i];
				col = convert[i + 1];
				System.out.println("Row====="+row);
				System.out.println("Col====="+col);
				
				switch (twoConsecutive[row][col]) {
				case 0:
					/*segSeq = segSeq + letterSeq.charAt(i);
					resultText = resultText + input.charAt(i);
					letterSeq1 = letterSeq.substring(i);
					input1 = input.substring(i);
					System.out.println(" \n Segmented sequence :"+segSeq);
					System.out.println("Result text : \t"+resultText);
					System.out.println("\n Input 1 \t"+input1);
					System.out.println("Letter sequence1 "+letterSeq1);
					
					break;*/
					segSeq += letterSeq.charAt(i);
					resultText += input.charAt(i);
					letterSeq1 = letterSeq.substring(i+1);
					System.out.println(segSeq);

					System.out.println(resultText);

					System.out.println("Leave of the LetterSequence" + letterSeq1);
					System.out.println();

					input1 = input.substring(i+1);
					System.out.println("Leave of the Input Sequence " + input1);
					System.out.println();
					break;
					
				case 1:
					System.out.println("col = "+convert[i + 1]);
					System.out.println("row="+convert[i]);
					segSeq = segSeq + letterSeq.charAt(i) + "|";
					resultText = resultText + input.charAt(i) + " | ";
					System.out.println("\n Segment Sequence:== \t"+segSeq);
					System.out.println("\n Result Text: \t"+resultText);
					break;
				case 2:
					segSeq = segSeq + letterSeq.charAt(i);
					resultText = resultText + input.charAt(i);
					break;
				case 9:	// 9 is equal to U
					letterSeq1 = letterSeq.substring(i);
					input1 = input.substring(i);
					String twoChar = String.valueOf(letterSeq.charAt(i))
							+ String.valueOf(letterSeq.charAt(i + 1));
					secondTable(convert[i + 2], twoChar, i, convert);
					System.out.println("Letter Sequence1 : \t"+letterSeq1);
					System.out.println("Input 1: \t"+input1);
					System.out.println("Two Character : \t "+twoChar);
					break;
				}
				
				//System.out.println(" \n Result Text " + i + " : " + resultText);
		
			}
		}
		
		static void secondTable(int c, String s, int i, int[] convert) {
				int a = 0;
				int j = 0;
				int[][] threeConsecutive = { { 3, 1, 1, 1, 1, 1, 1, 9, 1, 1, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 3, 1, 1, 1, 1, 1, 1, 9, 1, 1, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
															{ 0, 1, 1, 1, 1, 1, 1, 9, 1, 0, 1, 1, 1 } }; // Define the end of each row is add one (1) 
			
				if (s.equals("AC"))			a = 0;
						else if (s.equals("CC"))		a = 1;
								else if (s.equals("EC"))				a = 2;
										else if (s.equals("FC"))			a = 3;
											else if (s.equals("MC"))		a = 4;
												else if (s.equals("VC")) 		a = 5;
			
			switch (threeConsecutive[a][c]) {
						case 0	:	segSeq = segSeq + letterSeq1.charAt(0);
										resultText = resultText + input1.charAt(0);
										System.out.println("Segment sequence : "+segSeq);
										System.out.println("Segment myanmar sequence:"+resultText);
										break;
						case 1	:	segSeq = segSeq + letterSeq1.charAt(0) + ",";
										resultText = resultText + input1.charAt(0) + " , ";
										System.out.println("Segment sequence :==== "+segSeq);
										System.out.println("Segment myanmar sequence:==="+resultText);
										break;
						case 9	:	letterSeq2 = letterSeq1.substring(j);
										input2 = input1.substring(j);
										String threeChars = s + String.valueOf(letterSeq2.charAt(2));
										thirdTable(convert[i + 3], threeChars, i, convert);
										System.out.println("Letter sequence2 : "+letterSeq2);
										System.out.println("Input myanmar sequence2:"+input2);
										System.out.println("Three Characters:"+threeChars);
										break;
			}
		}
		static void thirdTable(int c, String s1, int i, int[] convert) {
			
				int a = 0;
				int[][] fourConsecutive = { { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
														{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
														{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

				if (s1.equals("ACM"))		a = 0;
					else if (s1.equals("FCM"))	a = 1;
						else if (s1.equals("VCM"))	a = 2;
			
				switch (fourConsecutive[a][c]) {
						case 0	:	segSeq = segSeq + letterSeq1.charAt(0);
										resultText = resultText + input1.charAt(0);
										break;
						case 1	:	segSeq = segSeq + letterSeq1.charAt(0) + "|";
										resultText = resultText + input1.charAt(0) + " | ";
										break;
			}
			
		} //End of thirdTable function

	
	}
	


