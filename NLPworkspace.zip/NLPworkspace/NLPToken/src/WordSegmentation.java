import java.io.*;
public class WordSegmentation
 {
	static String input ="ကျောင်းသားများကစားနေကြသည်"; 
	//static String resultText= "ကျောင်း#သား#များ#က#စား#နေ#ကြ#သည်#";
	static String resultText="ကျောင်း#သို့#သွား#သည်#";
	//static String resultText= "ကျောင်း#သား#များ#ကျောင်း#သို့#သွား#ကြ#သည်#";
	//static String resultText= "ခွေး#သည်#လူ#ကို#ကိုက်#သည်#";
	//static String resultText= "လ#သည်#ကောင်းကင်#မှာ#ရှိ#သည်#";
	static String[] tokens	= new String[30];
	static String [] token2 = new String[30];
	static String [] token3 = new String[30];
	static String [] token4 = new String[30];
	static String[] textWords = new String[30];
	static String line = "";	
	public static void WordSyllable () throws  IOException 
	{	
		// variable declaration
		PrintWriter writer = new PrintWriter("RetrivaLexicon.txt", "UTF-8");
		String line = "";
		String tokenizedMynText = resultText;
		String delims = "#";
		tokens = tokenizedMynText.split(delims,0);
		String[] token1=new String[tokens.length+2];
		token1=tokens;
		int count =0;
		int i=0;
		int k =0;
		int tokenCount = tokens.length;
		System.out.println("\nMyanmar Token Length is " + tokenCount);						
		String t = "";
		String t2 = "";
		String t3 = "";
		//String t4 = "";
		// searching to only word syllable (not tag) in lexicon (text file)
		for ( count = 0; count < tokenCount; count++) {
				t += token1[count];							
				BufferedReader  br = new BufferedReader (new FileReader ("D:\\lexicon.txt"));	
				try {	
								while  ((line = br.readLine()) != null ) {
										 textWords = line.split("\t");	
										if(t.equals(textWords[1])  ) 	t2 =t;
												else if (t3.equals(textWords[1])  ) {
															token3[i++] =t3;	
															t3="";
													}							
								} 	//	while		
								if(!t.equals(t2)  ) {
											token2[k++] = t2;
											t3 = token1[count];
											//token2[i++] = t4;
											t = "";
											//t4="";
									}				
					}	//	try
				catch (Exception e2) 
					{
							System.out.println("Errors " + e2);
					}
		} 		// for		count
		
		System.out.println("\n ");
		token2[i++] = token1[count-1];	
		// Output the word syllable array matching from the lexicon 
		for ( count = 0 ;count <k; count++ ){
				System.out.println("Array String list 1 is "+token2[count]);
		}
		for ( count = 0 ;count < i ; count++ ){
			System.out.println("Array String list 2  is "+token3[count]);
	}
		for ( count = 0 ;count < i+k ; count++ ){
			token4[count] = token2[count];
			token4[count] = token3[count];
			System.out.println("Array String list  3 is "+token4[count]);
	}
		System.out.println("\n ");
		for (count=0;count<i;count++){
				BufferedReader  br = new BufferedReader(new FileReader("D:\\lexicon.txt"));	
				try {	
							while  ((line = br.readLine()) != null ) {
										String[] textWords = line.split("\t");	
										if(token4[count].equals(textWords[1])  ) {
												System.out.println("Found in Dictionary Words : "+textWords[1]+"\t"+textWords[2]+"\t"+textWords[3]+"\t"+textWords[4]+"\t"+textWords[5]);
												String s =textWords[1]+"\t"+textWords[2]+"\t"+textWords[3]+"\t"+textWords[4]+"\t"+textWords[5] + "\n";
											    writer.println(s+"\n");      
										}		// if
							}		//	while
				}		// try
			 catch (Exception e2) 
			{
					System.out.println("Errors " + e2);
			}
		}			//for 
		writer.close();		
	} 			// WordSyllable () function
	
/*	public static void AssignTag ()throws  IOException {
		
		PrintWriter writer = new PrintWriter("RetrivaLexicon.txt", "UTF-8");
		for (int count=0;count<token2.length;count++){
			BufferedReader  br = new BufferedReader(new FileReader("D:\\New\\a1\\RetrivaLexicon.txt"));	
			try {	
						while  ((line = br.readLine()) != null ) {
									String[] textWords = line.split("\t");	
									if(token2[count].equals(textWords[1])  ) {
											//System.out.println("Found in Dictionary Words : "+textWords[1]+"\t"+textWords[2]+"\t"+textWords[3]+"\t"+textWords[4]+"\t"+textWords[5]);
											//String s =textWords[1]+"\t"+textWords[2]+"\t"+textWords[3]+"\t"+textWords[4]+"\t"+textWords[5] + "\n";
										   // writer.println(s+"\n");      
									}		// if
						}		//	while
			}		// try
		 catch (Exception e2) 
		{
				System.out.println("Errors " + e2);
		}
	}			//for 
		writer.close();		
	} */
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
			System.out.println("Input Sentence is "+input);
			WordSyllable ();
			
		}
	}

