// Correct My Program
import java.lang.NullPointerException;
import java.io.*;
public class TokenExample 
{
	static String segSequence = "";
	static String resultSequence = "";
	static String letterSequence = "";
	//static String inputSequence="လူတိုင်းသည်တူညီလွတ်လပ်သော ဂုဏ်သိက္ခာဖြင့်လည်းကောင်း၊ တူညီလွတ်လပ်သော အခွင့်အရေးများဖြင့်လည်းကောင်း၊ မွေးဖွားလာသူများဖြစ်သည်။ ထိုသူတို့၌ပိုင်းခြားဝေဖန်တတ်သော ဉာဏ်နှင့် ကျင့်ဝတ် သိတတ်သောစိတ်တို့ရှိကြ၍ ထိုသူတို့သည် အချင်းချင်းမေတ္တာထား၍ ဆက်ဆံသင့်၏";

	static String inputSequence=" မြန်မာ";
	//static String inputSequence = "မြန်မာစာစကားသည်အရေးပါသည်";
	// static String
	// inputSequence="မြန်မာစာစကားကောင်းသည်မြန်မာကာကာသူဇူသည်သီ မေမီမွန်သည်ကျောင်းသူဖြစ်သည်";

	// static String inputSequence="​ကောင်း";
	static String letterSeq1, letterSeq2, letterSeq3;
	static String inputSeq1 = "";
	private static int[] convertArr = null;

	public static void main(String[] args) throws FileNotFoundException 
	{
		int TwoConsecutiveArr[][] = {
				{ -1, 7, 1, 1, 0, -1, 1, 0, 1, 0, 0, 1, 1 },
				{ 0, 7, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1 },
				{ -1, 1, 0, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 7, 1, 1, 2, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 7, 1, 1, 2, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 1, 1, 1, 0, -1, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ 2, 7, 1, 1, 0, 0, 1, 0, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1 },
				{ -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1 },
				{ 2, 7, 1, 1, 0, 0, 1, -1, 1, -1, 0, 1, 1 },
				{ -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 0, 1 } };

		String C = "ကခဂဃငစဆဇဈညဉဋဌဍဎဏတထဒဓနပဖဗဘမယရလဝသဟဠအ";

		String M = "ျြွှ";

		String V = "ါာိီုူေဲ";

		String S = "္";

		String A = "်";

		String F = "ံ့း";

		String I = "ဤ၏ဧဪ၌၍";

		String E = "ဥဦဣဩ၎";

		String G = "ဿ";

		String D = "၀၁၂၃၄၅၆၇၈၉";

		String P = "၊။";

		String W = " ";

		int i, j;

		System.out.println("input text is " + inputSequence);

		System.out.println("input text length is" + inputSequence.length());

		for (i = 0; i < inputSequence.length(); i++) {
			System.out.println("input sequenc of " + i + "="
					+ inputSequence.charAt(i));
			for (j = 0; j < C.length(); j++) {
				if (inputSequence.charAt(i) == C.charAt(j)) {
					letterSequence += "C";
				}
			}
			for (j = 0; j < M.length(); j++) {
				if (inputSequence.charAt(i) == M.charAt(j)) {
					letterSequence += "M";
				}
			}
			for (j = 0; j < V.length(); j++) {
				if (inputSequence.charAt(i) == V.charAt(j)) {
					letterSequence += "V";
				}
			}
			for (j = 0; j < S.length(); j++) {
				if (inputSequence.charAt(i) == S.charAt(j)) {
					letterSequence += "S";
				}
			}
			for (j = 0; j < A.length(); j++) {
				if (inputSequence.charAt(i) == A.charAt(j)) {
					letterSequence += "A";
				}
			}

			for (j = 0; j < F.length(); j++) {
				if (inputSequence.charAt(i) == F.charAt(j)) {
					letterSequence += "F";
				}
			}

			for (j = 0; j < I.length(); j++) {
				if (inputSequence.charAt(i) == I.charAt(j)) {
					letterSequence += "I";
				}
			}

			for (j = 0; j < E.length(); j++) {
				if (inputSequence.charAt(i) == E.charAt(j)) {
					letterSequence += "E";
				}
			}

			for (j = 0; j < G.length(); j++) {
				if (inputSequence.charAt(i) == G.charAt(j)) {
					letterSequence += "G";
				}
			}

			for (j = 0; j < D.length(); j++) {
				if (inputSequence.charAt(i) == D.charAt(j)) {
					letterSequence += "D";
				}
			}

			for (j = 0; j < P.length(); j++) {
				if (inputSequence.charAt(i) == P.charAt(j)) {
					letterSequence += "P";
				}
			}

			for (j = 0; j < W.length(); j++) {
				if (inputSequence.charAt(i) == W.charAt(j)) {
					letterSequence += "A";
				}
			}

		}
		letterSequence += "#";

		System.out.println("Letter Sequence :" + letterSequence);
		System.out.println();

		convertArr = new int[letterSequence.length() + 6];
		System.out.println("Convert length =" + convertArr.length);
		for (i = 0; i < letterSequence.length(); i++) {
			switch (letterSequence.charAt(i)) {
			case 'A':
				convertArr[i] = 0;
				break;

			case 'C':
				convertArr[i] = 1;
				break;

			case 'D':
				convertArr[i] = 2;
				break;

			case 'E':
				convertArr[i] = 3;
				break;

			case 'F':
				convertArr[i] = 4;
				break;

			case 'G':
				convertArr[i] = 5;
				break;

			case 'I':
				convertArr[i] = 6;
				break;

			case 'M':
				convertArr[i] = 7;
				break;

			case 'P':
				convertArr[i] = 8;
				break;

			case 'S':
				convertArr[i] = 9;
				break;

			case 'V':
				convertArr[i] = 10;
				break;

			case 'W':
				convertArr[i] = 11;
				break;

			case '#':
				convertArr[i] = 12;
				break;

			}
		}

		System.out.println("No. of inputString:   ");
		for (i = 0; i < convertArr.length; i++) {
			System.out.print(convertArr[i] + "  ");
		}

		System.out.println();

		int row = 0, col = 0;
		for (i = 0; i < convertArr.length - 7; i++) 
		{
			row = convertArr[i];
			col = convertArr[i + 1];

			switch (TwoConsecutiveArr[row][col]) 
			{
			case 0:
				segSequence += letterSequence.charAt(i);
				resultSequence += inputSequence.charAt(i);
				letterSeq1 = letterSequence.substring(i);
				System.out.println(segSequence);

				System.out.println(resultSequence);

				System.out.println("Leave of the LetterSequence" + letterSeq1);
				System.out.println();

				inputSeq1 = inputSequence.substring(i);
				System.out.println("Leave of the Input Sequence " + inputSeq1);
				System.out.println();
				break;

			case 1:
				segSequence = segSequence + letterSequence.charAt(i) + "#";
				resultSequence = resultSequence + inputSequence.charAt(i) + ",";
				break;

			case 2:
				segSequence = segSequence + letterSequence.charAt(i);
				resultSequence = resultSequence + inputSequence.charAt(i);
				break;

			case 7:
				letterSeq1 = letterSequence.substring(i);
				System.out.println("Substring of Letter Sequence: "
						+ letterSeq1);
				System.out.println();

				inputSeq1 = inputSequence.substring(i);
				System.out.println("Leave of the Input Sequence " + inputSeq1);
				System.out.println();

				// for myanmar
				/*
				 * if(i>=1 && letterSeq1.charAt(i-1)=='M' &&
				 * letterSeq1.charAt(i)=='C') { String
				 * twoCharacters=String.valueOf
				 * (letterSeq1.charAt(i-1))+String.valueOf
				 * (letterSeq1.charAt(i));
				 * System.out.println("Two Character of Letter Sequence"
				 * +twoCharacters); System.out.println();
				 * 
				 * SecondConsecutiveTable(convertArr[i+2],twoCharacters,i,convertArr
				 * ); break; }
				 */
				/*
				 * else if(i>=1 && letterSeq1.charAt(i)=='A' &&
				 * letterSeq1.charAt(i)=='C') { String
				 * twoCharacters=String.valueOf
				 * (letterSeq1.charAt(i))+String.valueOf
				 * (letterSeq1.charAt(i+1));
				 * System.out.println("Two Character of Letter Sequence"
				 * +twoCharacters); System.out.println();
				 * 
				 * SecondConsecutiveTable(convertArr[i+2],twoCharacters,i,convertArr
				 * ); break; }
				 */

				// for zar zar
				String twoCharacters = String.valueOf(letterSequence.charAt(i))
						+ String.valueOf(letterSequence.charAt(i + 1));
				System.out.println("Two Character of Letter Sequence"
						+ twoCharacters);
				System.out.println();

				SecondConsecutiveTable(convertArr[i + 2], twoCharacters, i);
				break;

			}
		}

		System.out.println("Tokenized Letter Sequence :" + segSequence);
		System.out.println();
		System.out.println("Tokenized Resulted Sequence :" + resultSequence);
		System.out.println();

		// To read homonyms from notepad
		String filePath = "D:\\homonyms.txt";
		BufferedReader br;
		String line = "";

		// For To check word is homonym or not
		String tokenizedMynText = resultSequence;
		String delims = ",";
		System.out.println("Tokenized Text String: " + tokenizedMynText);
		String[] tokens = tokenizedMynText.split(delims);
		int tokenCount = tokens.length;
		System.out.println("Length is " + tokenCount);
		for (int count = 0; count < tokenCount; count++)
		{
			System.out.println("Split Output: " + tokens[count]);
			System.out.println();
			br = new BufferedReader(new FileReader(filePath));
			// System.out.println(filePath);
			try {
				while ((line = br.readLine()) != null) 
				{
					String[] textWords = line.split(" ");
					System.out.println(" Homonym Words in notepad ");
					System.out.println("----------------------");
					for (String words : textWords) 
					{
						System.out.println(words);
						System.out.println();
						if (words.equals(tokens[count]))
						{
							System.out.println(tokens[count]
									+ "  is homonym word");
							System.out.println();
							// System.out.println();
							// System.out.println(words);
						}

						/*
						 * else
						 *  {
						 * System.out.println(tokens[count]+"is not homonym word"
						 * ); 
						 * }
						 */

					}

				}

			} 
			catch (Exception e2) 
			{
				System.out.println("Errors " + e2);
			}
		}

	}

	private static void SecondConsecutiveTable(int col, String str, int i)
	{
		int row = 0;
		int[][] threeConsecutiveArr = {
				{ 3, 1, 1, 1, 1, 1, 1, 7, 1, 1, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 3, 1, 1, 1, 1, 1, 1, 7, 1, 1, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
				{ 0, 1, 1, 1, 1, 1, 1, 7, 1, 0, 1, 1, 1 } };
		if (str.equals("AC"))
			row = 0;

		else if (str.equals("CC"))
			row = 1;

		else if (str.equals("EC"))
			row = 2;

		else if (str.equals("FC"))
			row = 3;

		else if (str.equals("MC"))
			row = 4;

		else if (str.equals("VC"))
			row = 5;

		System.out.println("Row is " + row);
		System.out.println();
		System.out.println("Column is " + col);

		switch (threeConsecutiveArr[row][col]) {
		case 0:
			segSequence += str.charAt(0);
			resultSequence += inputSequence.charAt(i);
			break;

		case 1:
			segSequence += str.charAt(0) + "#";
			resultSequence += inputSequence.charAt(i) + ",";
			break;

		case 7:
			// letterSeq2=letterSeq1.substring(k);
			// System.out.println("Substring of Letter Sequence: "+letterSeq1);
			// System.out.println();

			// inputSeq2=inputSeq1.substring(k);
			// System.out.println("Leave of the Input Sequence "+inputSeq2);
			// System.out.println();
			// //System.out.println(letterSeq2.charAt(k-2)+" and "+letterSeq2.charAt(k-1)+"  "+letterSeq2.charAt(k));

			String threeCharacters = String.valueOf(letterSequence.charAt(i))
					+ String.valueOf(letterSequence.charAt(i + 1)
							+ String.valueOf(letterSequence.charAt(i + 2)));
			System.out.println("Three Characters of Letter Sequence"
					+ threeCharacters);
			// System.out.println();

			ThreeConsecutiveTable(convertArr[i + 3], threeCharacters, i);
			break;

		}

	}

	private static void ThreeConsecutiveTable(int column, String str, int i) 
	{
		int row = 0;
		int[][] fourConsecutiveArr = {
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
				{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };
		if (str.equals("ACM"))
			row = 0;

		else if (str.equals("FCM"))
			row = 1;

		else if (str.equals("VCM"))
			row = 2;
		switch (fourConsecutiveArr[row][column]) 
		{
		case 1:
			segSequence += str.charAt(0) + "#";
			resultSequence += inputSequence.charAt(i) + ",";
			break;
		}
	}


}
